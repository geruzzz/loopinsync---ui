export default function Home() {
  return (
    <main style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>Selamat datang di LoopinSync</h1>
      <p>Mini App yang terhubung dengan WorldApp & Loopin Token.</p>
    </main>
  );
}
